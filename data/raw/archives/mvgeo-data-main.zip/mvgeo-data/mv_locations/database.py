"""Build a single SQLite database from the generated JSON/GeoJSON outputs.

The schema is intentionally simple: one table per logical layer, with the
original properties as columns and geometry stored as GeoJSON text. Point
layers also get ``longitude``/``latitude`` columns, and the island table gets
``min_lon``/``min_lat``/``max_lon``/``max_lat`` plus its polygon geometry.
"""

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_FILENAME = "maldives.db"
SCHEMA_VERSION = 1

CORE_TABLES = ["atolls", "islands", "roads", "addresses"]

_INTEGER, _REAL, _TEXT = "INTEGER", "REAL", "TEXT"
_RANK = {_INTEGER: 0, _REAL: 1, _TEXT: 2}


def _quote(name):
    return '"' + str(name).replace('"', '""') + '"'


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _load(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _column_type(value):
    if isinstance(value, bool):
        return _INTEGER
    if isinstance(value, int):
        return _INTEGER
    if isinstance(value, float):
        return _REAL
    return _TEXT


def infer_columns(records, forced=None):
    order = []
    seen = set()
    for record in records:
        for key in record:
            if key not in seen:
                seen.add(key)
                order.append(key)

    types = {}
    for key in order:
        kind = _INTEGER
        seen_value = False
        for record in records:
            value = record.get(key)
            if value is None:
                continue
            seen_value = True
            candidate = _column_type(value)
            if _RANK[candidate] > _RANK[kind]:
                kind = candidate
            if kind == _TEXT:
                break
        types[key] = kind if seen_value else _TEXT

    for key, kind in (forced or {}).items():
        if key in types:
            types[key] = kind
    return [(key, types[key]) for key in order]


def _to_sql(value):
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return value


def _create_table(conn, table, columns):
    definitions = ", ".join(f"{_quote(name)} {kind}" for name, kind in columns)
    conn.execute(f"CREATE TABLE {_quote(table)} ({definitions})")


def _insert(conn, table, columns, records):
    names = ", ".join(_quote(name) for name, _ in columns)
    placeholders = ", ".join("?" for _ in columns)
    sql = f"INSERT INTO {_quote(table)} ({names}) VALUES ({placeholders})"
    batch = []
    for record in records:
        batch.append(tuple(_to_sql(record.get(name)) for name, _ in columns))
        if len(batch) >= 1000:
            conn.executemany(sql, batch)
            batch.clear()
    if batch:
        conn.executemany(sql, batch)


def _write_table(conn, table, records, forced=None):
    columns = infer_columns(records, forced=forced)
    _create_table(conn, table, columns)
    _insert(conn, table, columns, records)
    return {name for name, _ in columns}


def _layer_records(feature_collection):
    records = []
    for index, feature in enumerate(feature_collection.get("features", [])):
        record = dict(feature.get("properties") or {})
        record["fid"] = index
        geometry = feature.get("geometry")
        record["geometry"] = geometry
        if geometry and geometry.get("type") == "Point":
            coordinates = geometry.get("coordinates") or []
            if len(coordinates) >= 2:
                record.setdefault("longitude", coordinates[0])
                record.setdefault("latitude", coordinates[1])
        records.append(record)
    return records


def _island_records(data_dir, islands):
    geometries = {}
    collection = _load(data_dir / "islands.geojson", {})
    for feature in collection.get("features", []):
        properties = feature.get("properties") or {}
        if "id" in properties:
            geometries[properties["id"]] = feature.get("geometry")

    records = []
    for island in islands:
        record = dict(island)
        bbox = record.get("bbox")
        if isinstance(bbox, list) and len(bbox) == 4:
            record["min_lon"], record["min_lat"], record["max_lon"], record["max_lat"] = bbox
        record["geometry"] = geometries.get(record.get("id"))
        records.append(record)
    return records


def _human_bytes(size):
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.0f} {unit}" if unit == "B" else f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def _add_indexes(conn, table, columns, wanted):
    for column in wanted:
        if column not in columns:
            continue
        name = f"idx_{table}_{column}"
        conn.execute(
            f"CREATE INDEX {_quote(name)} ON {_quote(table)} ({_quote(column)})"
        )


def build_sqlite(data_dir, meta=None):
    """Create ``data_dir/maldives.db`` and return a small summary dict."""
    data_dir = Path(data_dir)
    db_path = data_dir / DB_FILENAME
    if db_path.exists():
        db_path.unlink()

    atolls_doc = _load(data_dir / "atolls.json", {})
    islands_doc = _load(data_dir / "islands.json", {})
    roads_doc = _load(data_dir / "roads.json", {})
    addresses_doc = _load(data_dir / "addresses.json", {})
    index_doc = _load(data_dir / "layers" / "index.json", {"layers": []})

    atolls = atolls_doc.get("atolls", [])
    islands = _island_records(data_dir, islands_doc.get("islands", []))
    roads = roads_doc.get("roads", [])
    addresses = addresses_doc.get("addresses", [])

    conn = sqlite3.connect(str(db_path))
    try:
        conn.execute("PRAGMA journal_mode = OFF")
        conn.execute("PRAGMA synchronous = OFF")
        conn.execute("PRAGMA temp_store = MEMORY")
        conn.execute("PRAGMA page_size = 4096")
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")

        conn.execute("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)")
        conn.execute(
            "CREATE TABLE layers ("
            "name TEXT PRIMARY KEY, file TEXT, source_file TEXT, "
            "count INTEGER, geometry_types TEXT, fields TEXT)"
        )

        totals = 0
        tables = 0
        core = {
            "atolls": atolls,
            "islands": islands,
            "roads": roads,
            "addresses": addresses,
        }
        indexes = {
            "atolls": ["code", "name"],
            "islands": ["id", "island_code", "atoll", "name"],
            "roads": ["id", "island_id", "island", "name"],
            "addresses": ["id", "island_id", "island", "atoll", "road"],
        }

        for table in CORE_TABLES:
            records = core[table]
            columns = _write_table(conn, table, records)
            _add_indexes(conn, table, columns, indexes.get(table, []))
            totals += len(records)
            tables += 1

        for layer in index_doc.get("layers", []):
            name = layer.get("name")
            if not name or name in CORE_TABLES:
                continue
            collection = _load(data_dir / layer.get("file", ""), {})
            records = _layer_records(collection)
            forced = {"fid": _INTEGER, "geometry": _TEXT}
            columns = _write_table(conn, name, records, forced=forced)
            _add_indexes(
                conn, name, columns, ["id", "island_id", "island", "atoll"]
            )

            conn.execute(
                "INSERT INTO layers (name, file, source_file, count, "
                "geometry_types, fields) VALUES (?, ?, ?, ?, ?, ?)",
                (
                    name,
                    layer.get("file"),
                    layer.get("source_file"),
                    len(records),
                    json.dumps(layer.get("geometry_types") or []),
                    json.dumps(sorted(columns - {"fid", "geometry"})),
                ),
            )
            totals += len(records)
            tables += 1

        source = (meta or {}).get("source") or atolls_doc.get("source")
        generated_at = (meta or {}).get("generated_at") or utcnow()
        meta_rows = {
            "schema_version": SCHEMA_VERSION,
            "generated_at": generated_at,
            "source": source,
            "counts": (meta or {}).get("counts"),
            "quality": (meta or {}).get("quality"),
            "road_matching": (meta or {}).get("road_matching"),
            "data_availability": (meta or {}).get("data_availability"),
        }
        for key, value in meta_rows.items():
            if value is None:
                continue
            if not isinstance(value, str):
                value = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            conn.execute("INSERT INTO meta (key, value) VALUES (?, ?)", (key, value))

        conn.commit()
        conn.execute("VACUUM")
    finally:
        conn.close()

    size = db_path.stat().st_size
    return {
        "file": DB_FILENAME,
        "bytes": size,
        "size": _human_bytes(size),
        "tables": tables,
        "rows": totals,
        "generated_at": utcnow(),
    }
