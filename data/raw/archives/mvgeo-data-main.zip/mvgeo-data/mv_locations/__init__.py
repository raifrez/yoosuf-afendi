"""Scrape Maldives atoll/island/road/address data from the BBS GIS map."""

__version__ = "1.0.0"
