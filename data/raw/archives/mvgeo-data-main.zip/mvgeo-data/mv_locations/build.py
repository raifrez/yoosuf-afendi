"""Build normalized, searchable JSON from the raw BBS map layers."""

import difflib
import hashlib
from collections import Counter
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from .config import (
    ATOLL_ALIASES,
    DEFAULT_ROAD_RADIUS_M,
    DEFAULT_UNNAMED_ROAD_RADIUS_M,
    EXTRA_LAYER_SPECS,
    LAYER_ORDER,
)
from .database import build_sqlite
from .download import layer_paths
from .geo import (
    bbox_of_geometry,
    distance_to_geometry_m,
    haversine_m,
    point_in_geometry,
    point_segment_distance_m,
    polygon_area_m2,
)
from .layers import load_layer

SCHEMA_VERSION = 1
FALLBACK_MAX_M = 5000.0

_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def clean(value):
    if value is None:
        return None
    text = str(value).replace("\r", " ").replace("\n", " ").strip()
    text = re.sub(r"\s+", " ", text)
    return text or None


def coerce(value, kind=""):
    if value is None:
        return None
    if kind == "int":
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return None
    if kind == "float":
        try:
            return round(float(value), 6)
        except (TypeError, ValueError):
            return None
    if kind == "bool":
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("1", "1.0", "true", "y", "yes")
    if isinstance(value, (int, float, bool)):
        return value
    return clean(value)


def normalize_name(value):
    text = clean(value)
    if not text:
        return ""
    return _NON_ALNUM.sub("", text.lower())


def stable_id(prefix, *parts):
    payload = "|".join("" if p is None else str(p) for p in parts)
    digest = hashlib.sha1(payload.encode("utf-8")).hexdigest()[:12]
    return f"{prefix}{digest.upper()}"


def write_json(path, value, indent=2):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        if indent:
            json.dump(value, handle, ensure_ascii=False, indent=indent)
        else:
            json.dump(value, handle, ensure_ascii=False, separators=(",", ":"))
        handle.write("\n")
    tmp.replace(path)


class IslandIndex:
    def __init__(self, islands):
        self.islands = islands
        self.items = [
            (island["_bbox"], island["_geometry"], island) for island in islands
        ]

    def find(self, lon, lat):
        for bbox, geometry, island in self.items:
            if not (
                bbox[0] <= lon <= bbox[2] and bbox[1] <= lat <= bbox[3]
            ):
                continue
            if point_in_geometry(lon, lat, geometry):
                return island
        return None

    def nearest(self, lon, lat, max_m=FALLBACK_MAX_M):
        best_island = None
        best_distance = float("inf")
        for island in self.islands:
            distance = distance_to_geometry_m(lon, lat, island["_geometry"])
            if distance < best_distance:
                best_distance = distance
                best_island = island
        if best_island is not None and best_distance <= max_m:
            return best_island
        return None


def build_atolls(raw):
    records = {}
    for feature in raw["features"]:
        props = feature["properties"]
        code = clean(props.get("codeAbbrev"))
        if not code:
            continue
        numeric = props.get("atollCode")
        area_m2 = coerce(props.get("Shape_Area"), "float")
        records[code] = {
            "id": code,
            "code": code,
            "name": clean(props.get("CodeName")),
            "name_english": clean(props.get("Name_Engli")),
            "name_official": clean(props.get("Name_Offic")),
            "capital": clean(props.get("Name_Capit")),
            "code_numeric": int(numeric) if numeric not in (None, "") else None,
            "status": clean(props.get("cityStatus")),
            "population_total": coerce(props.get("V01"), "int"),
            "population_male": coerce(props.get("V02"), "int"),
            "population_female": coerce(props.get("V03"), "int"),
            "population_maldivian": coerce(props.get("V04"), "int"),
            "population_foreign": coerce(props.get("V07"), "int"),
            "population_pct": coerce(props.get("totPer"), "float"),
            "population_foreign_pct": coerce(props.get("frgPer"), "float"),
            "population_maldives_share_pct": coerce(props.get("mldPerc"), "float"),
            "population_growth_pct": coerce(props.get("pgrowPerc"), "float"),
            "area_km2": round(area_m2 / 1_000_000, 4) if area_m2 else None,
            "population_density_per_km2": round(
                coerce(props.get("V01"), "int") / (area_m2 / 1_000_000), 1
            )
            if area_m2
            else None,
            "island_count": 0,
            "inhabited_island_count": 0,
            "address_island_count": 0,
            "road_count": 0,
            "address_count": 0,
            "_order": numeric if numeric is not None else 999,
        }
    return records


def atoll_alias_map(atolls):
    aliases = dict(ATOLL_ALIASES)
    for code, atoll in atolls.items():
        aliases[code] = code
        if atoll.get("name"):
            aliases[atoll["name"]] = code
        if atoll.get("name_english"):
            aliases[atoll["name_english"]] = code
    return aliases


def canonical_atoll(raw_code, aliases):
    code = clean(raw_code)
    if not code:
        return None
    if code in aliases:
        return aliases[code]
    lowered = {str(key).lower(): value for key, value in aliases.items()}
    return lowered.get(code.lower(), code)


def build_islands(raw, atolls, aliases):
    islands = []
    seen = set()
    fcode_counts = Counter(
        clean(feature["properties"].get("FCODE")) for feature in raw["features"]
    )
    for feature in raw["features"]:
        props = feature["properties"]
        atoll_code = canonical_atoll(props.get("Atoll"), aliases)
        atoll = atolls.get(atoll_code)
        fcode = clean(props.get("FCODE"))
        name = clean(props.get("IslandName"))
        island_code = clean(props.get("islandCode"))
        longitude = props.get("longitude")
        latitude = props.get("latitude")
        dedupe_key = (
            fcode,
            name,
            clean(props.get("fname")),
            round(float(longitude), 6) if longitude is not None else None,
            round(float(latitude), 6) if latitude is not None else None,
        )
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        if fcode and fcode_counts[fcode] == 1:
            island_id = fcode
        elif fcode:
            suffix = stable_id(
                "",
                name,
                atoll_code,
                island_code,
                round(float(longitude), 6) if longitude is not None else None,
                round(float(latitude), 6) if latitude is not None else None,
            )[-6:]
            island_id = f"{fcode}-{suffix}"
        else:
            island_id = stable_id(
                "I",
                name,
                atoll_code,
                island_code,
                round(float(longitude), 6) if longitude is not None else None,
                round(float(latitude), 6) if latitude is not None else None,
            )
        area_m2 = polygon_area_m2(feature["geometry"])
        area_km2 = round(area_m2 / 1_000_000, 5) if area_m2 else None
        population_total = coerce(props.get("v01"), "int")
        island = {
            "id": island_id,
            "island_code": island_code,
            "fcode": fcode,
            "name": name,
            "full_name": clean(props.get("fname")),
            "atoll": atoll_code,
            "atoll_name": atoll["name_english"] if atoll else None,
            "category": clean(props.get("category")),
            "category2": clean(props.get("categ2")),
            "is_capital": clean(props.get("capital")) == "Y",
            "latitude": float(latitude) if latitude is not None else None,
            "longitude": float(longitude) if longitude is not None else None,
            "population_total": population_total,
            "population_male": coerce(props.get("v02"), "int"),
            "population_female": coerce(props.get("v03"), "int"),
            "population_maldivian": coerce(props.get("v04"), "int"),
            "population_foreign": coerce(props.get("v07"), "int"),
            "area_km2": area_km2,
            "population_density_per_km2": round(population_total / area_km2, 1)
            if population_total and area_km2
            else None,
            "bbox": None,
            "address_count": 0,
            "road_count": 0,
            "_geometry": feature["geometry"],
            "_bbox": bbox_of_geometry(feature["geometry"]),
        }
        if island["bbox"] is None:
            island["bbox"] = island["_bbox"]
        islands.append(island)
    return islands


def public_island(island):
    return {
        "id": island["id"],
        "island_code": island["island_code"],
        "fcode": island["fcode"],
        "name": island["name"],
        "full_name": island["full_name"],
        "atoll": island["atoll"],
        "atoll_name": island["atoll_name"],
        "category": island["category"],
        "category2": island["category2"],
        "is_capital": island["is_capital"],
        "latitude": island["latitude"],
        "longitude": island["longitude"],
        "bbox": [round(value, 7) for value in island["bbox"]]
        if island["bbox"]
        else None,
        "population_total": island["population_total"],
        "population_male": island["population_male"],
        "population_female": island["population_female"],
        "population_maldivian": island["population_maldivian"],
        "population_foreign": island["population_foreign"],
        "area_km2": island["area_km2"],
        "population_density_per_km2": island["population_density_per_km2"],
        "address_count": island["address_count"],
        "road_count": island["road_count"],
    }


def _road_lookup_island(island_index, geometry):
    for lon, lat in _geometry_points(geometry):
        island = island_index.find(lon, lat)
        if island:
            return island
    return None


def _geometry_points(geometry):
    stack = [geometry["coordinates"]]
    while stack:
        value = stack.pop()
        if not value:
            continue
        if isinstance(value[0], (int, float)):
            yield value[0], value[1]
        else:
            stack.extend(value)


def build_roads(raw, island_index):
    groups = {}
    for index, feature in enumerate(raw["features"]):
        props = feature["properties"]
        geometry = feature["geometry"]
        island = _road_lookup_island(island_index, geometry)
        name = clean(props.get("roadEN"))
        name_dhivehi = clean(props.get("roadDI"))
        object_id = clean(props.get("OBJECTID"))

        key = (
            ("named", island["id"], name.lower())
            if name
            else ("unnamed", clean(props.get("OBJECTID")) or str(index))
        )
        group = groups.get(key)
        if group is None:
            if name:
                road_id = stable_id("R", island["id"] if island else None, name.lower())
            else:
                first = next(_geometry_points(geometry), (None, None))
                road_id = stable_id("R", "unnamed", object_id, first[0], first[1])
            group = {
                "id": road_id,
                "name": name,
                "name_dhivehi": name_dhivehi,
                "island": island["name"] if island else None,
                "island_id": island["id"] if island else None,
                "island_code": island["island_code"] if island else None,
                "island_fcode": island["fcode"] if island else None,
                "atoll": island["atoll"] if island else None,
                "atoll_name": island["atoll_name"] if island else None,
                "segment_count": 0,
                "length_m": 0.0,
                "dead_end_segments": 0,
                "address_count": 0,
                "geometry": {"type": "MultiLineString", "coordinates": []},
                "_island": island,
            }
            groups[key] = group

        group["geometry"]["coordinates"].extend(geometry["coordinates"])
        group["segment_count"] += 1
        length = props.get("SHAPE_Leng")
        if length is not None:
            group["length_m"] += float(length)
        if props.get("deadEnd") in (1, 1.0, "1", True):
            group["dead_end_segments"] += 1

    roads = list(groups.values())
    for road in roads:
        road["length_m"] = round(road["length_m"], 1)
        road["dead_end"] = road["dead_end_segments"] == road["segment_count"]
    roads.sort(
        key=lambda road: (
            road["atoll"] or "",
            road["island"] or "",
            road["name"] or "\uffff",
            road["id"],
        )
    )
    return roads


def road_public(road):
    return {
        "id": road["id"],
        "name": road["name"],
        "name_dhivehi": road["name_dhivehi"],
        "island": road["island"],
        "island_id": road["island_id"],
        "island_code": road["island_code"],
        "island_fcode": road["island_fcode"],
        "atoll": road["atoll"],
        "atoll_name": road["atoll_name"],
        "segment_count": road["segment_count"],
        "length_m": road["length_m"],
        "dead_end": road["dead_end"],
        "address_count": road["address_count"],
        "geometry": road["geometry"],
    }


def build_name_index(islands):
    index = {}
    for island in islands:
        key = normalize_name(island["name"])
        if key:
            index.setdefault(key, []).append(island)
    return index


def resolve_island(lon, lat, source_name, island_index, name_index):
    island = island_index.find(lon, lat)
    if island:
        return island, "polygon"

    key = normalize_name(source_name)
    method = "name"
    candidates = list(name_index.get(key, ()))

    if not candidates and key:
        matches = difflib.get_close_matches(key, name_index.keys(), n=5, cutoff=0.86)
        candidates = [island for match in matches for island in name_index[match]]
        method = "fuzzy"

    if candidates:
        candidates = [i for i in candidates if i["longitude"] is not None]
        if candidates:
            nearest = min(
                candidates,
                key=lambda i: haversine_m(lon, lat, i["longitude"], i["latitude"]),
            )
            distance = haversine_m(
                lon, lat, nearest["longitude"], nearest["latitude"]
            )
            if distance <= FALLBACK_MAX_M:
                return nearest, method

    nearest = island_index.nearest(lon, lat, FALLBACK_MAX_M)
    if nearest is not None:
        return nearest, "nearest"

    return None, "unmatched"


def flatten_road_segments(roads):
    by_island = {}
    for road in roads:
        if not road["island_id"]:
            continue
        bucket = by_island.setdefault(road["island_id"], [])
        for line in road["geometry"]["coordinates"]:
            for start, end in zip(line, line[1:]):
                bucket.append((road, start[0], start[1], end[0], end[1]))
    return by_island


def nearest_road(lon, lat, segments, named_radius, unnamed_radius):
    best_named = (float("inf"), None)
    best_unnamed = (float("inf"), None)
    for road, ax, ay, bx, by in segments:
        distance = point_segment_distance_m(lon, lat, ax, ay, bx, by)
        if road["name"]:
            if distance < best_named[0]:
                best_named = (distance, road)
        elif distance < best_unnamed[0]:
            best_unnamed = (distance, road)

    if best_named[1] is not None and best_named[0] <= named_radius:
        return best_named[1], best_named[0]
    if best_unnamed[1] is not None and best_unnamed[0] <= unnamed_radius:
        return best_unnamed[1], best_unnamed[0]
    return None, None


def build_addresses(
    raw,
    island_index,
    name_index,
    road_segments,
    named_radius,
    unnamed_radius,
):
    addresses = []
    quality = {"polygon": 0, "name": 0, "fuzzy": 0, "nearest": 0, "unmatched": 0}
    with_road = 0
    used_ids = set()

    for feature in raw["features"]:
        props = feature["properties"]
        lon, lat = feature["geometry"]["coordinates"][:2]
        source_name = clean(props.get("IslandName"))
        name = clean(props.get("hname"))
        full_name = clean(props.get("hfname"))

        island, match = resolve_island(
            lon, lat, source_name, island_index, name_index
        )
        quality[match] += 1

        road = None
        road_distance = None
        if island:
            segments = road_segments.get(island["id"], ())
            if segments:
                road, road_distance = nearest_road(
                    lon, lat, segments, named_radius, unnamed_radius
                )
        if road:
            with_road += 1
            road["address_count"] += 1

        address_id = stable_id(
            "A", source_name, full_name or name, round(lon, 7), round(lat, 7)
        )
        if address_id in used_ids:
            suffix = 2
            while f"{address_id}-{suffix}" in used_ids:
                suffix += 1
            address_id = f"{address_id}-{suffix}"
        used_ids.add(address_id)

        address = {
            "id": address_id,
            "name": name,
            "full_name": full_name,
            "source_island_name": source_name,
            "island": island["name"] if island else None,
            "island_id": island["id"] if island else None,
            "island_code": island["island_code"] if island else None,
            "island_fcode": island["fcode"] if island else None,
            "atoll": island["atoll"] if island else None,
            "atoll_name": island["atoll_name"] if island else None,
            "road": road["name"] if road else None,
            "road_id": road["id"] if road else None,
            "road_unnamed": bool(road and not road["name"]),
            "road_distance_m": round(road_distance, 1)
            if road_distance is not None
            else None,
            "match": match,
            "latitude": round(lat, 7),
            "longitude": round(lon, 7),
        }
        if island is None or normalize_name(source_name) != normalize_name(
            island["name"]
        ):
            address["source_island_name"] = source_name
        else:
            address.pop("source_island_name", None)

        addresses.append(address)

    addresses.sort(
        key=lambda a: (
            a["atoll"] or "",
            a["island"] or "",
            a["road"] or "",
            a["name"] or "",
            a["id"],
        )
    )
    return addresses, quality, with_road


def summarize_quality(quality, addresses, with_road):
    total = len(addresses)
    return {
        "addresses": total,
        "matched_by_polygon": quality["polygon"],
        "matched_by_name": quality["name"],
        "matched_by_fuzzy_name": quality["fuzzy"],
        "matched_by_nearest_island": quality["nearest"],
        "unmatched": quality["unmatched"],
        "with_road": with_road,
        "without_road": total - with_road,
    }


def normalize_props(props, fields, aliases):
    out = {}
    for source, dest, kind in fields:
        if source not in props:
            continue
        value = coerce(props[source], kind)
        if dest in ("atoll", "atoll_code") and isinstance(value, str):
            value = canonical_atoll(value, aliases)
        out[dest] = value
    return out


def feature_island(feature, island_index):
    geometry = feature["geometry"]
    if geometry["type"] == "Point":
        lon, lat = geometry["coordinates"][:2]
        return island_index.find(lon, lat)
    island = _road_lookup_island(island_index, geometry)
    if island:
        return island
    first = next(_geometry_points(geometry), None)
    if first:
        return island_index.nearest(first[0], first[1], FALLBACK_MAX_M)
    return None


def enrich_props(props, island):
    if island is None:
        props.setdefault("island", None)
        props.setdefault("island_id", None)
        props.setdefault("island_code", None)
        props.setdefault("island_fcode", None)
        props.setdefault("atoll", props.get("atoll"))
        props.setdefault("atoll_name", None)
        return props
    props["island"] = island["name"]
    props["island_id"] = island["id"]
    props["island_code"] = island["island_code"]
    props["island_fcode"] = island["fcode"]
    props["atoll"] = island["atoll"]
    props["atoll_name"] = island["atoll_name"]
    return props


def build_extra_layers(data_dir, island_index, aliases, generated_at, source):
    paths = layer_paths(data_dir, LAYER_ORDER, strict=False)
    layers_dir = data_dir / "layers"
    index = []
    counts = {}

    for logical in LAYER_ORDER:
        path = paths.get(logical)
        if path is None:
            continue
        spec = EXTRA_LAYER_SPECS[logical]
        raw = load_layer(path)
        geometry_types = set()
        features = []
        for feature in raw["features"]:
            props = normalize_props(feature["properties"], spec["fields"], aliases)
            if spec.get("enrich"):
                enrich_props(props, feature_island(feature, island_index))
            geometry_types.add(feature["geometry"]["type"])
            features.append(
                {
                    "type": "Feature",
                    "properties": props,
                    "geometry": feature["geometry"],
                }
            )

        collection = {
            "type": "FeatureCollection",
            "name": logical,
            "generated_at": generated_at,
            "source": source,
            "count": len(features),
            "features": features,
        }
        write_json(layers_dir / f"{logical}.geojson", collection, indent=None)

        counts[logical] = len(features)
        index.append(
            {
                "name": logical,
                "file": f"layers/{logical}.geojson",
                "source_file": path.name,
                "count": len(features),
                "geometry_types": sorted(geometry_types),
                "enriched": bool(spec.get("enrich")),
                "fields": [dest for _, dest, _ in spec["fields"]],
            }
        )

    write_json(
        layers_dir / "index.json",
        {
            "generated_at": generated_at,
            "source": source,
            "count": len(index),
            "layers": index,
        },
        indent=2,
    )
    return counts


def build(data_dir, named_radius=None, unnamed_radius=None, indent=2):
    data_dir = Path(data_dir)
    named_radius = (
        DEFAULT_ROAD_RADIUS_M if named_radius is None else float(named_radius)
    )
    unnamed_radius = (
        DEFAULT_UNNAMED_ROAD_RADIUS_M
        if unnamed_radius is None
        else float(unnamed_radius)
    )

    paths = layer_paths(data_dir, ["atolls", "islands", "addresses", "roads"])
    atolls_raw = load_layer(paths["atolls"])
    islands_raw = load_layer(paths["islands"])
    roads_raw = load_layer(paths["roads"])
    addresses_raw = load_layer(paths["addresses"])

    atolls = build_atolls(atolls_raw)
    aliases = atoll_alias_map(atolls)
    islands = build_islands(islands_raw, atolls, aliases)
    island_index = IslandIndex(islands)
    name_index = build_name_index(islands)

    roads = build_roads(roads_raw, island_index)
    road_segments = flatten_road_segments(roads)

    addresses, quality, with_road = build_addresses(
        addresses_raw,
        island_index,
        name_index,
        road_segments,
        named_radius,
        unnamed_radius,
    )

    islands_by_id = {island["id"]: island for island in islands}
    for address in addresses:
        if address["island_id"] in islands_by_id:
            islands_by_id[address["island_id"]]["address_count"] += 1
    for road in roads:
        if road["island_id"] in islands_by_id:
            islands_by_id[road["island_id"]]["road_count"] += 1

    for island in islands:
        atoll = atolls.get(island["atoll"])
        if not atoll:
            continue
        atoll["island_count"] += 1
        if island["category"] == "Inhabited":
            atoll["inhabited_island_count"] += 1
        if island["address_count"]:
            atoll["address_island_count"] += 1
        atoll["address_count"] += island["address_count"]
        atoll["road_count"] += island["road_count"]

    island_public = {island["id"]: public_island(island) for island in islands}
    roads_public = [road_public(road) for road in roads]

    roads_by_island = {}
    for road in roads_public:
        if road["island_id"]:
            roads_by_island.setdefault(road["island_id"], []).append(road)

    addresses_by_island = {}
    unmatched_addresses = []
    for address in addresses:
        if address["island_id"]:
            addresses_by_island.setdefault(address["island_id"], []).append(address)
        else:
            unmatched_addresses.append(address)

    unmatched_roads = [road for road in roads_public if not road["island_id"]]

    atolls_out = []
    for atoll in sorted(
        atolls.values(), key=lambda a: (a["_order"], a["code"])
    ):
        atoll_islands = [
            island
            for island in islands
            if island["atoll"] == atoll["code"]
        ]
        atoll_islands.sort(key=lambda i: (i["name"] or "", i["id"]))
        island_nodes = []
        for island in atoll_islands:
            node = dict(island_public[island["id"]])
            node["roads"] = roads_by_island.get(island["id"], [])
            node["addresses"] = addresses_by_island.get(island["id"], [])
            island_nodes.append(node)

        atoll_node = {key: value for key, value in atoll.items() if key != "_order"}
        atoll_node["islands"] = island_nodes
        atolls_out.append(atoll_node)

    generated_at = utcnow()
    source = "https://app.statisticsmaldives.gov.mv/gismaps/statsmap/"

    layer_counts = build_extra_layers(
        data_dir, island_index, aliases, generated_at, source
    )

    counts = {
        "atolls": len(atolls),
        "islands": len(islands),
        "inhabited_islands": sum(
            1 for island in islands if island["category"] == "Inhabited"
        ),
        "islands_with_addresses": sum(
            1 for island in islands if island["address_count"]
        ),
        "islands_with_roads": sum(1 for island in islands if island["road_count"]),
        "roads": len(roads_public) - len(unmatched_roads),
        "road_segments": sum(road["segment_count"] for road in roads_public),
        "addresses": len(addresses),
        "layers": layer_counts,
    }

    source_layers = {}
    try:
        manifest = json.loads(
            (data_dir / "manifest.json").read_text(encoding="utf-8")
        )
        for entry in manifest.get("layers", {}).values():
            logical = entry.get("logical")
            if logical:
                source_layers[logical] = {
                    "file": entry.get("path"),
                    "url": entry.get("url"),
                    "last_modified": entry.get("last_modified"),
                    "fetched_at": entry.get("fetched_at"),
                    "bytes": entry.get("bytes"),
                }
    except (OSError, ValueError):
        pass

    meta = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": generated_at,
        "source": source,
        "source_layers": source_layers,
        "counts": counts,
        "quality": summarize_quality(quality, addresses, with_road),
        "road_matching": {
            "named_radius_m": named_radius,
            "unnamed_radius_m": unnamed_radius,
        },
        "data_availability": {
            "road_islands": sorted(
                {
                    road["island"]
                    for road in roads_public
                    if road["island"] is not None
                }
            ),
            "notes": [
                "Roads are only published for a subset of islands in this export; "
                "addresses on other islands have road=null.",
                "Addresses are named places/buildings from the BBS Address layer, "
                "not postal addresses.",
                "Islands, roads and addresses are joined spatially, so source "
                "spelling variants are preserved in source_island_name.",
            ],
        },
    }

    atolls_flat = [
        {key: value for key, value in atoll.items() if key != "islands"}
        for atoll in atolls_out
    ]

    outputs = {
        "atolls.json": {
            "generated_at": generated_at,
            "source": source,
            "count": len(atolls_flat),
            "atolls": atolls_flat,
        },
        "islands.json": {
            "generated_at": generated_at,
            "source": source,
            "count": len(islands),
            "islands": sorted(
                (island_public[island["id"]] for island in islands),
                key=lambda i: (i["atoll"] or "", i["name"] or ""),
            ),
        },
        "roads.json": {
            "generated_at": generated_at,
            "source": source,
            "count": counts["roads"],
            "segment_count": counts["road_segments"],
            "roads": roads_public,
        },
        "addresses.json": {
            "generated_at": generated_at,
            "source": source,
            "count": len(addresses),
            "addresses": addresses,
        },
        "maldives.json": {
            "generated_at": generated_at,
            "source": source,
            "counts": counts,
            "atolls": atolls_out,
            "unmatched_addresses": unmatched_addresses,
            "unmatched_roads": unmatched_roads,
        },
        "islands.geojson": {
            "type": "FeatureCollection",
            "name": "MaldivesIslands",
            "generated_at": generated_at,
            "source": source,
            "features": [
                {
                    "type": "Feature",
                    "properties": island_public[island["id"]],
                    "geometry": island["_geometry"],
                }
                for island in islands
            ],
        },
        "meta.json": meta,
    }

    for name, value in outputs.items():
        write_json(data_dir / name, value, indent=indent)

    meta["sqlite"] = build_sqlite(data_dir, meta=meta)
    write_json(data_dir / "meta.json", meta, indent=indent)

    return counts, meta
