"""Configuration for the Maldives GIS scraper."""

from pathlib import Path

BASE_URL = "https://app.statisticsmaldives.gov.mv/gismaps/statsmap/"
INDEX_URL = BASE_URL + "index.html"
LAYER_URL = BASE_URL + "layers/{name}.js"

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA_DIR = ROOT / "data"

# The four layers that drive the atoll -> island -> road -> address hierarchy.
# Layer file names carry a version suffix that changes when the Bureau of
# Statistics republishes the map, so layers are matched by prefix.
CORE_PREFIXES = {
    "AdministrativeAtoll": "atolls",
    "AdministrativeIsland": "islands",
    "Address": "addresses",
    "Road": "roads",
}

# Every other layer on the map page. ``fields`` maps source property -> output
# property, with an optional type: int, float, bool, or "" (clean string /
# keep number). ``enrich`` adds the spatially joined island/atoll fields.
EXTRA_LAYER_SPECS = {
    "island_names": {
        "prefix": "IslandName",
        "enrich": False,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("ORIG_FID", "orig_fid", "int"),
        ],
    },
    "atoll_boundaries": {
        "prefix": "AtollBoundaryLine",
        "enrich": False,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("SHAPE_Leng", "length_m", "float"),
        ],
    },
    "atoll_capitals": {
        "prefix": "AtollCapital",
        "enrich": True,
        "fields": [
            ("atoll", "atoll", ""),
            ("islandName", "capital", ""),
            ("V01", "population_total", "int"),
            ("V02", "population_male", "int"),
            ("V03", "population_female", "int"),
        ],
    },
    "airports": {
        "prefix": "Airport",
        "enrich": True,
        "fields": [
            ("Aerodrome", "name", ""),
            ("Aerodrome_", "operator", ""),
            ("Code", "aircraft_code", ""),
            ("Three_lett", "iata", ""),
            ("Four_Lette", "icao", ""),
            ("Internatio", "international", "bool"),
            ("lat", "latitude", "float"),
            ("long_", "longitude", "float"),
        ],
    },
    "resorts": {
        "prefix": "Resort",
        "enrich": True,
        "fields": [
            ("resortName", "name", ""),
            ("Atoll", "atoll", ""),
            ("Island", "island_source_name", ""),
            ("FCOde", "island_fcode", ""),
            ("Rooms", "rooms", "int"),
            ("Beds", "beds", "int"),
            ("Owner_Less", "owner", ""),
            ("Management", "management", ""),
            ("Operator", "operator", ""),
            ("State", "state", ""),
            ("Phone", "phone", ""),
            ("Fax", "fax", ""),
            ("Email", "email", ""),
            ("Resort_Pho", "resort_phone", ""),
            ("Resort_Fax", "resort_fax", ""),
            ("Resort_Ema", "resort_email", ""),
            ("lat", "latitude", "float"),
            ("long", "longitude", "float"),
        ],
    },
    "schools": {
        "prefix": "School",
        "enrich": True,
        "fields": [
            ("name", "name", ""),
            ("status", "status", ""),
            ("pid2", "provider_id", ""),
            ("lng", "longitude", "float"),
            ("ltt", "latitude", "float"),
        ],
    },
    "hotels": {
        "prefix": "Hotels",
        "enrich": True,
        "fields": [
            ("Name", "name", ""),
            ("Address", "address", ""),
            ("atoll_isla", "island_full", ""),
            ("fcode", "island_fcode", ""),
            ("lat", "latitude", "float"),
            ("lng", "longitude", "float"),
        ],
    },
    "guest_houses": {
        "prefix": "GuestHouse",
        "enrich": True,
        "fields": [
            ("Name", "name", ""),
            ("Address", "address", ""),
            ("Rooms", "rooms", "int"),
        ],
    },
    "mosques": {
        "prefix": "Mosque",
        "enrich": True,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("PARCEL_NAM", "name", ""),
        ],
    },
    "government_offices": {
        "prefix": "GovernmentOffice",
        "enrich": True,
        "fields": [
            ("officeNa_1", "name", ""),
            ("oaddress", "address", ""),
            ("ocontact", "contact", ""),
            ("email", "email", ""),
        ],
    },
    "protected_areas": {
        "prefix": "ProtectedAreaEPA",
        "enrich": True,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("Atoll", "atoll", ""),
            ("Name_Engli", "name", ""),
            ("Name_Dhive", "name_dhivehi", ""),
            ("Category", "category", ""),
            ("Type", "type", ""),
            ("Area_Ha", "area_ha", "float"),
            ("Date_Decla", "date_declared", ""),
            ("Date_Manag", "date_managed", ""),
            ("Amended_De", "amended_declaration", ""),
            ("Manag_Plan", "management_plan", ""),
            ("ManagPlanA", "management_plan_agency", ""),
            ("Internatio", "international_designation", ""),
            ("HandOver_1", "handover", ""),
            ("Original_D", "declaration_reference", ""),
            ("About_PA", "description_dhivehi", ""),
            ("Related_Li", "related_links", ""),
            ("Shape_Area", "area_m2", "float"),
        ],
    },
    "reefs": {
        "prefix": "Reef",
        "enrich": True,
        "fields": [("Name", "name", "")],
    },
    "wetlands": {
        "prefix": "wetland",
        "enrich": True,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("name", "name", ""),
            ("Shape_Area", "area_m2", "float"),
            ("Shape_Leng", "length_m", "float"),
        ],
    },
    "vegetation": {
        "prefix": "veg",
        "enrich": True,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("wardName", "ward", ""),
            ("wardNameDI", "ward_dhivehi", ""),
            ("Shape_Area", "area_m2", "float"),
            ("Shape_Leng", "length_m", "float"),
        ],
    },
    "causeways": {
        "prefix": "causeway",
        "enrich": True,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("Shape_Area", "area_m2", "float"),
            ("Shape_Leng", "length_m", "float"),
        ],
    },
    "runways": {
        "prefix": "runway",
        "enrich": True,
        "fields": [
            ("OBJECTID", "object_id", "int"),
            ("Shape_Area", "area_m2", "float"),
            ("Shape_Leng", "length_m", "float"),
        ],
    },
    "wards": {
        "prefix": "WardMaaleandFoahmulah",
        "enrich": True,
        "fields": [
            ("wardName", "name", ""),
            ("wardNameDI", "name_dhivehi", ""),
            ("Shape_Area", "area_m2", "float"),
            ("SHAPE_Leng", "length_m", "float"),
        ],
    },
    "parcels": {
        "prefix": "ParcelCategory",
        "enrich": True,
        "fields": [
            ("Category", "category", ""),
            ("Shape_Area", "area_m2", "float"),
        ],
    },
    "street_blocks": {
        "prefix": "StreetBlock",
        "enrich": True,
        "fields": [
            ("block_code", "block_code", ""),
            ("fcode", "island_fcode", ""),
        ],
    },
    "plot_lines": {
        "prefix": "plotLine",
        "enrich": True,
        "fields": [
            ("block_code", "block_code", ""),
            ("fcode", "island_fcode", ""),
        ],
    },
    "other_inhabited": {
        "prefix": "OtherInhabited",
        "enrich": True,
        "fields": [
            ("atoll", "atoll", ""),
            ("islandName", "island_source_name", ""),
            ("V01", "population_total", "int"),
            ("V02", "population_male", "int"),
            ("V03", "population_female", "int"),
        ],
    },
    "uninhabited": {
        "prefix": "Uninhabited",
        "enrich": True,
        "fields": [
            ("atoll", "atoll", ""),
            ("islandName", "island_source_name", ""),
            ("category2", "category", ""),
            ("latitude", "latitude", "float"),
            ("longitude", "longitude", "float"),
            ("V01", "population_total", "int"),
        ],
    },
}

ALL_PREFIXES = {
    **CORE_PREFIXES,
    **{spec["prefix"]: logical for logical, spec in EXTRA_LAYER_SPECS.items()},
}

# Stable output order for the data/layers directory.
LAYER_ORDER = list(EXTRA_LAYER_SPECS)

# Some islands carry a non-canonical atoll label in the source. These are
# still resolved from the atoll layer's CodeName field, but keep the explicit
# fallbacks here for safety.
ATOLL_ALIASES = {
    "Baa": "B",
    "Raa": "R",
    "Gaafu Alifu": "GA",
    "Maale City": "D",
    "Male City": "D",
    "Maale": "D",
}

USER_AGENT = (
    "mv-locations/1.0 (+https://app.statisticsmaldives.gov.mv/gismaps/statsmap/) "
    "Python-urllib"
)

DEFAULT_ROAD_RADIUS_M = 30.0
DEFAULT_UNNAMED_ROAD_RADIUS_M = 15.0

# ---------------------------------------------------------------------------
# S3-compatible object storage (path-style).
# Credentials come from the environment / Gitea secrets, never from the repo.
# ---------------------------------------------------------------------------
DEFAULT_S3_ENDPOINT = "https://s3.cubable.date"
DEFAULT_S3_BUCKET = "mvgeo-data"
DEFAULT_S3_REGION = "us-east-1"
DEFAULT_S3_PREFIX = ""

# Public read-only mirror used for README links. Never derive this from
# S3_ENDPOINT: in CI that can be a private host/port that must not be published.
DEFAULT_READ_BASE = "https://index.cubable.date/sd/OLDOu9rQ"
DEFAULT_READ_SUFFIX = "?pwd=geo"

S3_ENV = {
    "endpoint": "S3_ENDPOINT",
    "bucket": "S3_BUCKET",
    "region": "S3_REGION",
    "prefix": "S3_PREFIX",
    "public_base": "S3_PUBLIC_BASE",
    "access_key": "S3_ACCESS_KEY_ID",
    "secret_key": "S3_SECRET_ACCESS_KEY",
}

# Markers the `status` command replaces inside README.md.
README_STATUS_START = "<!-- DATA-STATUS:START -->"
README_STATUS_END = "<!-- DATA-STATUS:END -->"
