"""Download the QGIS2Web layers with ETag / Last-Modified caching."""

import gzip
import hashlib
import json
import os
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from .config import (
    ALL_PREFIXES,
    CORE_PREFIXES,
    INDEX_URL,
    LAYER_URL,
    USER_AGENT,
)
from .layers import discover_layers, pick_layers


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _request(url, headers=None, retries=3, timeout=90):
    request_headers = {
        "User-Agent": USER_AGENT,
        "Accept": "*/*",
        "Accept-Encoding": "gzip",
    }
    if headers:
        request_headers.update(headers)

    last_error = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=request_headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                body = response.read()
                if response.headers.get("Content-Encoding") == "gzip":
                    body = gzip.decompress(body)
                return response.status, dict(response.headers), body
        except urllib.error.HTTPError as exc:
            if exc.code == 304:
                return 304, dict(exc.headers), b""
            last_error = exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last_error = exc
        if attempt < retries - 1:
            time.sleep(2 ** attempt)

    raise RuntimeError(f"failed to download {url}: {last_error}")


def _read_manifest(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"layers": {}}


def _write_atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def fetch(data_dir, everything=True):
    data_dir = Path(data_dir)
    raw_dir = data_dir / "raw"
    manifest_path = data_dir / "manifest.json"
    raw_dir.mkdir(parents=True, exist_ok=True)

    status, _, index_body = _request(INDEX_URL)
    index_html = index_body.decode("utf-8", "replace")
    layer_names = discover_layers(index_html)
    if not layer_names:
        raise RuntimeError("no layers found on the map page")

    prefixes = ALL_PREFIXES if everything else CORE_PREFIXES
    selected = pick_layers(layer_names, prefixes, required=not everything)
    manifest = _read_manifest(manifest_path)
    manifest["base_url"] = INDEX_URL.rsplit("/", 1)[0] + "/"
    manifest["updated_at"] = utcnow()

    for logical, layer_name in sorted(selected.items()):
        url = LAYER_URL.format(name=layer_name)
        target = raw_dir / f"{layer_name}.js"
        previous = manifest["layers"].get(layer_name, {})

        conditional = {}
        if target.exists() and previous.get("path") == target.name:
            if previous.get("etag"):
                conditional["If-None-Match"] = previous["etag"]
            if previous.get("last_modified"):
                conditional["If-Modified-Since"] = previous["last_modified"]

        try:
            status, headers, body = _request(url, headers=conditional)
        except RuntimeError:
            status, headers, body = _request(url)

        entry = {
            "logical": logical,
            "prefix": layer_name.rsplit("_", 1)[0],
            "url": url,
            "path": target.name,
            "fetched_at": utcnow(),
        }

        if status == 304 and target.exists():
            entry.update(
                {
                    "status": "not-modified",
                    "etag": previous.get("etag") or headers.get("ETag"),
                    "last_modified": previous.get("last_modified")
                    or headers.get("Last-Modified"),
                    "sha256": previous.get("sha256"),
                    "bytes": previous.get("bytes") or target.stat().st_size,
                }
            )
        else:
            _write_atomic(target, body)
            entry.update(
                {
                    "status": "downloaded",
                    "etag": headers.get("ETag"),
                    "last_modified": headers.get("Last-Modified"),
                    "sha256": hashlib.sha256(body).hexdigest(),
                    "bytes": len(body),
                }
            )

        manifest["layers"][layer_name] = entry

    _write_atomic(
        manifest_path,
        (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode("utf-8"),
    )
    return manifest


def layer_paths(data_dir, logical_names=None, strict=True):
    """Resolve logical layer names to raw files using the manifest."""
    data_dir = Path(data_dir)
    raw_dir = data_dir / "raw"
    manifest = _read_manifest(data_dir / "manifest.json")

    resolved = {}
    for layer_name, entry in manifest.get("layers", {}).items():
        logical = entry.get("logical")
        if logical_names and logical not in logical_names:
            continue
        path = raw_dir / entry["path"]
        if path.exists():
            resolved[logical] = path

    if strict and logical_names:
        missing = sorted(set(logical_names) - set(resolved))
        if missing:
            raise RuntimeError(
                "missing layer(s): "
                + ", ".join(missing)
                + f" in {raw_dir}. Run `python -m mv_locations fetch` first."
            )
    return resolved
