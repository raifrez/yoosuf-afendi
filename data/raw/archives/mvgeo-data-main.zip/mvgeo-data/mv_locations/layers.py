"""Read QGIS2Web layer exports and write normal JSON."""

import json
import re
from pathlib import Path

_VAR_RE = re.compile(r"=\s*(\{.*\})\s*;?\s*$", re.S)


def parse_layer_text(text):
    """Turn ``var json_Address_24 = {...};`` into a dict."""
    match = _VAR_RE.search(text)
    if not match:
        raise ValueError("not a QGIS2Web layer export")
    return json.loads(match.group(1))


def load_layer(path):
    path = Path(path)
    return parse_layer_text(path.read_text(encoding="utf-8-sig"))


def find_layer_file(raw_dir, prefix):
    """Return the newest raw file matching ``<prefix>_<version>.js``."""
    raw_dir = Path(raw_dir)
    matches = sorted(raw_dir.glob(f"{prefix}_*.js"))
    if not matches:
        return None
    return max(matches, key=lambda p: p.stat().st_mtime)


def discover_layers(index_html):
    """Map every layer file name in the map page to its URL path."""
    names = sorted(set(re.findall(r"layers/([A-Za-z0-9_]+)\.js", index_html)))
    return names


def prefix_of(layer_name):
    return layer_name.rsplit("_", 1)[0]


def pick_layers(layer_names, prefixes, required=False):
    """Map logical prefix -> concrete layer file name.

    ``prefixes`` is a dict of prefix -> logical name. If a prefix has multiple
    versions the highest suffix wins.
    """
    by_prefix = {}
    for name in layer_names:
        prefix = prefix_of(name)
        if prefix not in prefixes:
            continue
        current = by_prefix.get(prefix)
        if current is None or _version(name) > _version(current):
            by_prefix[prefix] = name

    if required:
        missing = sorted(set(prefixes) - set(by_prefix))
        if missing:
            raise RuntimeError(
                "map page is missing expected layer(s): " + ", ".join(missing)
            )
    return {prefixes[p]: name for p, name in by_prefix.items()}


def _version(layer_name):
    try:
        return int(layer_name.rsplit("_", 1)[1])
    except (IndexError, ValueError):
        return -1
