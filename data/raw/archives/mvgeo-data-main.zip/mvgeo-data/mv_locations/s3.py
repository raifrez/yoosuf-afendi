"""Minimal AWS Signature V4 client for S3-compatible path-style buckets.

Only PUT and HEAD are implemented, which is all this project needs. Using the
standard library keeps the scraper dependency-free; ``boto3`` is deliberately
avoided.
"""

import hashlib
import hmac
import os
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from .config import (
    DEFAULT_READ_BASE,
    DEFAULT_READ_SUFFIX,
    DEFAULT_S3_BUCKET,
    DEFAULT_S3_ENDPOINT,
    DEFAULT_S3_PREFIX,
    DEFAULT_S3_REGION,
    S3_ENV,
    USER_AGENT,
)

_ALGORITHM = "AWS4-HMAC-SHA256"
_SERVICE = "s3"


class S3Error(RuntimeError):
    pass


def settings(overrides=None):
    overrides = overrides or {}

    def resolve(key, default=None):
        value = overrides.get(key)
        if value:
            return value
        return os.environ.get(S3_ENV[key]) or default

    endpoint = resolve("endpoint", DEFAULT_S3_ENDPOINT).rstrip("/")
    bucket = resolve("bucket", DEFAULT_S3_BUCKET)
    prefix = (resolve("prefix", DEFAULT_S3_PREFIX) or "").strip("/")
    explicit_base = resolve("public_base")
    if explicit_base:
        public_base = explicit_base.rstrip("/")
        public_suffix = ""
    else:
        public_base = DEFAULT_READ_BASE.rstrip("/")
        if prefix:
            public_base = f"{public_base}/{prefix}"
        public_suffix = DEFAULT_READ_SUFFIX
    return {
        "endpoint": endpoint,
        "bucket": bucket,
        "region": resolve("region", DEFAULT_S3_REGION),
        "prefix": prefix,
        "public_base": public_base,
        "public_suffix": public_suffix,
        "access_key": resolve("access_key"),
        "secret_key": resolve("secret_key"),
    }


def public_url(config, key):
    key = key.lstrip("/")
    return f"{config['public_base']}/{key}{config['public_suffix']}"


def _sign(key, message):
    return hmac.new(key, message.encode("utf-8"), hashlib.sha256).digest()


def _signing_key(secret, date, region):
    k_date = _sign(("AWS4" + secret).encode("utf-8"), date)
    k_region = _sign(k_date, region)
    k_service = _sign(k_region, _SERVICE)
    return _sign(k_service, "aws4_request")


def _canonical_path(bucket, key):
    path = f"/{bucket}/{key}" if key else f"/{bucket}"
    return urllib.parse.quote(path, safe="/-_.~")


def signed_request(
    config, method, key="", data=b"", content_type=None, extra_headers=None, timeout=120
):
    region = config["region"]
    host = urllib.parse.urlparse(config["endpoint"]).netloc
    now = datetime.now(timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    date = now.strftime("%Y%m%d")

    payload_hash = hashlib.sha256(data).hexdigest()
    canonical_uri = _canonical_path(config["bucket"], key)

    headers = {
        "host": host,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amz_date,
    }
    if content_type:
        headers["content-type"] = content_type
    for name, value in (extra_headers or {}).items():
        headers[name.lower()] = value

    signed_names = sorted(headers)
    canonical_headers = "".join(f"{name}:{headers[name]}\n" for name in signed_names)
    signed_headers = ";".join(signed_names)

    canonical_request = "\n".join(
        [method, canonical_uri, "", canonical_headers, signed_headers, payload_hash]
    )
    scope = f"{date}/{region}/{_SERVICE}/aws4_request"
    string_to_sign = "\n".join(
        [
            _ALGORITHM,
            amz_date,
            scope,
            hashlib.sha256(canonical_request.encode("utf-8")).hexdigest(),
        ]
    )
    signing_key = _signing_key(config["secret_key"], date, region)
    signature = hmac.new(
        signing_key, string_to_sign.encode("utf-8"), hashlib.sha256
    ).hexdigest()

    authorization = (
        f"{_ALGORITHM} Credential={config['access_key']}/{scope}, "
        f"SignedHeaders={signed_headers}, Signature={signature}"
    )

    request_headers = {
        "Host": host,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amz_date,
        "Authorization": authorization,
        "User-Agent": USER_AGENT,
    }
    if content_type:
        request_headers["Content-Type"] = content_type
    for name, value in (extra_headers or {}).items():
        request_headers[name] = value

    url = f"{config['endpoint']}{canonical_uri}"
    request = urllib.request.Request(
        url, data=data if method in ("PUT", "POST") else None, headers=request_headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, dict(response.headers), response.read()
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return 404, dict(exc.headers), b""
        raise S3Error(
            f"{method} {canonical_uri} failed: {exc.code} {exc.reason}"
        ) from exc
    except urllib.error.URLError as exc:
        raise S3Error(f"{method} {canonical_uri} failed: {exc.reason}") from exc


def head(config, key):
    return signed_request(config, "HEAD", key=key, timeout=30)


def put(config, key, path, content_type):
    data = Path(path).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    status, headers, _ = signed_request(
        config,
        "PUT",
        key=key,
        data=data,
        content_type=content_type,
        extra_headers={"x-amz-meta-sha256": digest},
        timeout=600,
    )
    if status not in (200, 201):
        raise S3Error(f"PUT {key} returned {status}")
    return digest, len(data)


def _header(headers, name):
    for key, value in headers.items():
        if key.lower() == name.lower():
            return value
    return None


def remote_matches(config, key, digest, size):
    """True when the stored object already has our SHA-256 + matching size.

    Some S3-compatible servers return an empty ETag, so the hash is stored in
    ``x-amz-meta-sha256`` on upload and compared first.
    """
    try:
        status, headers, _ = head(config, key)
    except S3Error:
        return False
    if status != 200:
        return False
    stored = (_header(headers, "x-amz-meta-sha256") or "").strip('"')
    length = _header(headers, "Content-Length")
    if stored:
        return stored == digest and (length is None or int(length) == size)
    etag = (_header(headers, "ETag") or "").strip('"')
    return bool(etag) and etag == digest and (
        length is None or int(length) == size
    )


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def content_type_for(path):
    name = Path(path).name.lower()
    if name.endswith(".geojson"):
        return "application/geo+json"
    if name.endswith(".json"):
        return "application/json"
    if name.endswith((".db", ".sqlite", ".sqlite3")):
        return "application/vnd.sqlite3"
    return "application/octet-stream"


def collect_files(data_dir, include_raw=False, prefix=""):
    """Relative S3 keys for every generated file under ``data_dir``."""
    data_dir = Path(data_dir)
    files = []
    for path in sorted(data_dir.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(data_dir)
        if rel.parts and rel.parts[0] == "raw" and not include_raw:
            continue
        if path.name.endswith(".tmp"):
            continue
        key = "/".join(([prefix] if prefix else []) + list(rel.parts))
        files.append((key, path))
    return files
