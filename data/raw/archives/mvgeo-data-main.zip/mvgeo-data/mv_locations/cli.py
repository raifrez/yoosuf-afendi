"""Command line interface."""

import argparse
import sys
from pathlib import Path

from . import s3
from .build import build
from .config import DEFAULT_DATA_DIR, ROOT
from .download import fetch
from .status import render_block, summary_line, utcnow, write_readme


def _data_dir(value):
    return Path(value).resolve()


def cmd_fetch(args):
    manifest = fetch(args.data_dir, everything=not args.core)
    layers = manifest.get("layers", {})
    changed = [name for name, entry in layers.items() if entry.get("status") == "downloaded"]
    cached = [name for name, entry in layers.items() if entry.get("status") == "not-modified"]
    print(f"fetched {len(layers)} layer(s): {len(changed)} changed, {len(cached)} not modified")
    for name, entry in sorted(layers.items()):
        print(f"  {entry.get('status', '?'):13} {name} ({(entry.get('bytes') or 0):,} bytes)")


def cmd_build(args):
    counts, meta = build(
        args.data_dir,
        named_radius=args.road_radius,
        unnamed_radius=args.unnamed_road_radius,
        indent=None if args.compact else 2,
    )
    print(f"atolls:   {counts['atolls']}")
    print(f"islands:  {counts['islands']} ({counts['inhabited_islands']} inhabited)")
    print(f"roads:    {counts['roads']} roads / {counts['road_segments']} segments")
    print(f"addresses:{counts['addresses']}")
    layer_counts = counts.get("layers", {})
    print(
        f"layers:   {sum(layer_counts.values())} records "
        f"across {len(layer_counts)} extra layer(s)"
    )
    quality = meta["quality"]
    print(
        "matched:  "
        f"{quality['matched_by_polygon']} polygon, "
        f"{quality['matched_by_name']} name, "
        f"{quality['matched_by_fuzzy_name']} fuzzy, "
        f"{quality['unmatched']} unmatched"
    )
    print(f"output:   {args.data_dir}")


def cmd_update(args):
    cmd_fetch(args)
    cmd_build(args)


def cmd_upload(args):
    overrides = {
        "endpoint": args.endpoint,
        "bucket": args.bucket,
        "region": args.region,
        "prefix": args.prefix,
    }
    config = s3.settings(overrides)
    if not args.dry_run and (not config["access_key"] or not config["secret_key"]):
        raise RuntimeError(
            "S3 credentials missing: set S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY"
        )

    files = s3.collect_files(
        args.data_dir, include_raw=args.include_raw, prefix=config["prefix"]
    )
    uploaded = skipped = 0
    uploaded_bytes = 0
    for key, path in files:
        content_type = s3.content_type_for(path)
        if args.dry_run:
            print(f"  would upload {key} ({path.stat().st_size:,} bytes)")
            continue
        if args.skip_unchanged:
            digest = s3.sha256_file(path)
            if s3.remote_matches(config, key, digest, path.stat().st_size):
                skipped += 1
                continue
        _, size = s3.put(config, key, path, content_type)
        uploaded += 1
        uploaded_bytes += size
        print(f"  uploaded {key} ({size:,} bytes)")

    print(
        f"s3://{config['bucket']}: {uploaded} uploaded ({uploaded_bytes:,} bytes), "
        f"{skipped} unchanged, {len(files)} total"
    )


def cmd_status(args):
    ran_at = utcnow()
    block, changed, meta = render_block(args.data_dir, ran_at=ran_at)
    if args.write_readme:
        write_readme(args.readme, block)
    if args.summary:
        print(summary_line(meta, changed, ran_at=ran_at))
    else:
        print(block)


def parser():
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "--data-dir",
        type=_data_dir,
        default=DEFAULT_DATA_DIR,
        help="output directory (default: %(default)s)",
    )

    root = argparse.ArgumentParser(
        prog="mv_locations",
        description="Download and normalize the Maldives BBS GIS map layers.",
    )
    sub = root.add_subparsers(dest="command", required=True)

    fetch_parser = sub.add_parser(
        "fetch", parents=[common], help="download raw layers"
    )
    fetch_parser.add_argument(
        "--core",
        action="store_true",
        help="download only the 4 core layers (atolls, islands, roads, addresses)",
    )
    fetch_parser.set_defaults(func=cmd_fetch)

    build_parser = sub.add_parser(
        "build", parents=[common], help="build normalized JSON from raw layers"
    )
    build_parser.add_argument(
        "--road-radius",
        type=float,
        default=30.0,
        help="max distance in metres to attach an address to a named road",
    )
    build_parser.add_argument(
        "--unnamed-road-radius",
        type=float,
        default=15.0,
        help="max distance in metres to attach an address to an unnamed road",
    )
    build_parser.add_argument(
        "--compact",
        action="store_true",
        help="write compact JSON instead of indented JSON",
    )
    build_parser.set_defaults(func=cmd_build)

    update_parser = sub.add_parser(
        "update", parents=[common], help="fetch then build"
    )
    update_parser.add_argument("--core", action="store_true", help="download only core layers")
    update_parser.add_argument("--road-radius", type=float, default=30.0)
    update_parser.add_argument("--unnamed-road-radius", type=float, default=15.0)
    update_parser.add_argument("--compact", action="store_true")
    update_parser.set_defaults(func=cmd_update)

    upload_parser = sub.add_parser(
        "upload", parents=[common], help="upload generated data to S3"
    )
    upload_parser.add_argument("--endpoint", help="override S3_ENDPOINT")
    upload_parser.add_argument("--bucket", help="override S3_BUCKET")
    upload_parser.add_argument("--region", help="override S3_REGION")
    upload_parser.add_argument("--prefix", help="key prefix inside the bucket")
    upload_parser.add_argument(
        "--include-raw", action="store_true", help="also upload data/raw/"
    )
    upload_parser.add_argument(
        "--no-skip-unchanged",
        dest="skip_unchanged",
        action="store_false",
        help="re-upload every object instead of skipping matching ETags",
    )
    upload_parser.add_argument("--dry-run", action="store_true")
    upload_parser.set_defaults(func=cmd_upload, skip_unchanged=True)

    status_parser = sub.add_parser(
        "status", parents=[common], help="render the README data status block"
    )
    status_parser.add_argument(
        "--readme",
        type=_data_dir,
        default=ROOT / "README.md",
        help="README to update (default: %(default)s)",
    )
    status_parser.add_argument(
        "--write-readme", action="store_true", help="replace the status block in the README"
    )
    status_parser.add_argument(
        "--summary", action="store_true", help="print a one-line summary for commit messages"
    )
    status_parser.set_defaults(func=cmd_status)

    return root


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        args.func(args)
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
