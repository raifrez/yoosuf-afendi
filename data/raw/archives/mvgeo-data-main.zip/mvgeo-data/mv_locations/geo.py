"""Small dependency-free geo helpers (WGS84 lon/lat only).

The source layers are small enough (a few thousand polygons and ~100k points)
that a bounding-box prefilter plus ray casting is fast, and avoids pulling in
GEOS/Shapely just to do a point-in-polygon join.
"""

import math

EARTH_RADIUS_M = 6_371_008.8
METERS_PER_DEG_LAT = 111_132.0


def iter_coords(geometry):
    """Yield every (lon, lat) pair in a GeoJSON geometry."""
    stack = [geometry["coordinates"]]
    while stack:
        value = stack.pop()
        if not value:
            continue
        if isinstance(value[0], (int, float)):
            yield value[0], value[1]
        else:
            stack.extend(value)


def bbox_of_geometry(geometry):
    xs = []
    ys = []
    for lon, lat in iter_coords(geometry):
        xs.append(lon)
        ys.append(lat)
    if not xs:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


def point_in_ring(x, y, ring):
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > y) != (yj > y):
            if x < (xj - xi) * (y - yi) / (yj - yi) + xi:
                inside = not inside
        j = i
    return inside


def point_in_polygon(x, y, polygon):
    if not point_in_ring(x, y, polygon[0]):
        return False
    for hole in polygon[1:]:
        if point_in_ring(x, y, hole):
            return False
    return True


def point_in_geometry(x, y, geometry):
    if geometry["type"] == "Polygon":
        return point_in_polygon(x, y, geometry["coordinates"])
    if geometry["type"] == "MultiPolygon":
        return any(point_in_polygon(x, y, poly) for poly in geometry["coordinates"])
    return False


def point_segment_distance_m(px, py, ax, ay, bx, by):
    """Approximate planar distance in metres around the Maldives."""
    lat_scale = METERS_PER_DEG_LAT
    lon_scale = METERS_PER_DEG_LAT * math.cos(math.radians(py))

    ax = (ax - px) * lon_scale
    ay = (ay - py) * lat_scale
    bx = (bx - px) * lon_scale
    by = (by - py) * lat_scale

    dx = bx - ax
    dy = by - ay
    if dx == 0.0 and dy == 0.0:
        return math.hypot(ax, ay)
    t = -(ax * dx + ay * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    return math.hypot(ax + t * dx, ay + t * dy)


def _ring_area_m2(ring):
    if len(ring) < 3:
        return 0.0
    lat0 = sum(point[1] for point in ring) / len(ring)
    lon_scale = METERS_PER_DEG_LAT * math.cos(math.radians(lat0))
    area = 0.0
    for i in range(len(ring)):
        x1, y1 = ring[i][0] * lon_scale, ring[i][1] * METERS_PER_DEG_LAT
        x2, y2 = ring[(i + 1) % len(ring)][0] * lon_scale, ring[(i + 1) % len(ring)][
            1
        ] * METERS_PER_DEG_LAT
        area += x1 * y2 - x2 * y1
    return abs(area) / 2.0


def polygon_area_m2(geometry):
    """Approximate polygon/multipolygon area in square metres (WGS84)."""
    polygons = (
        [geometry["coordinates"]]
        if geometry["type"] == "Polygon"
        else geometry["coordinates"]
    )
    total = 0.0
    for polygon in polygons:
        if not polygon:
            continue
        total += _ring_area_m2(polygon[0])
        for hole in polygon[1:]:
            total -= _ring_area_m2(hole)
    return abs(total)


def distance_to_geometry_m(x, y, geometry):
    """Shortest distance from a point to any edge of a Polygon/MultiPolygon."""
    polygons = (
        [geometry["coordinates"]]
        if geometry["type"] == "Polygon"
        else geometry["coordinates"]
    )
    best = float("inf")
    for polygon in polygons:
        for ring in polygon:
            for start, end in zip(ring, ring[1:]):
                distance = point_segment_distance_m(
                    x, y, start[0], start[1], end[0], end[1]
                )
                if distance < best:
                    best = distance
    return best


def haversine_m(lon1, lat1, lon2, lat2):
    lon1, lat1, lon2, lat2 = map(math.radians, (lon1, lat1, lon2, lat2))
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2 * EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(a)))
