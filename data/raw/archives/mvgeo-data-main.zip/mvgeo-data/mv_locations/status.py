"""Render the data status block that lives in README.md."""

import json
from datetime import datetime, timezone
from pathlib import Path

from .config import README_STATUS_END, README_STATUS_START
from .s3 import public_url, settings

CORE_ROWS = [
    ("atolls", "atolls.json", "atolls"),
    ("islands", "islands.json", "islands"),
    ("roads", "roads.json", "roads"),
    ("addresses", "addresses.json", "addresses"),
]


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _load(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def changed_layers(manifest):
    layers = (manifest or {}).get("layers", {})
    return sorted(
        name for name, entry in layers.items() if entry.get("status") == "downloaded"
    )


def summary_line(meta, changed, ran_at=None):
    counts = (meta or {}).get("counts", {})
    layer_counts = counts.get("layers", {})
    parts = [
        f"{counts.get('atolls', 0)} atolls",
        f"{counts.get('islands', 0)} islands",
        f"{counts.get('roads', 0)} roads",
        f"{counts.get('addresses', 0):,} addresses",
    ]
    if layer_counts:
        parts.append(f"{sum(layer_counts.values()):,} layer records")
    body = ", ".join(parts)
    if changed:
        if len(changed) <= 4:
            change = ", ".join(changed)
        else:
            change = f"{len(changed)} layers"
        return f"refresh {ran_at or utcnow()} ({body}; changed: {change})"
    return f"refresh {ran_at or utcnow()} ({body}; no source changes)"


def render_block(data_dir, ran_at=None):
    data_dir = Path(data_dir)
    meta = _load(data_dir / "meta.json", {})
    index = _load(data_dir / "layers" / "index.json", {"layers": []})
    manifest = _load(data_dir / "manifest.json", {})
    config = settings()
    changed = changed_layers(manifest)
    generated = meta.get("generated_at", "?")
    counts = meta.get("counts", {})

    lines = [
        README_STATUS_START,
        "",
        f"_Last run: `{ran_at or utcnow()}` · data generated: `{generated}`_",
        "",
        f"Download base: `{config['public_base']}/`",
        "",
        "| Dataset | Records | Object |",
        "| --- | ---: | --- |",
    ]
    for logical, filename, count_key in CORE_ROWS:
        count = counts.get(count_key, 0)
        lines.append(f"| {logical} | {count:,} | [`{filename}`]({public_url(config, filename)}) |")
    for layer in index.get("layers", []):
        file = layer.get("file", "")
        name = layer.get("name", "")
        count = layer.get("count", 0)
        lines.append(f"| {name} | {count:,} | [`{file}`]({public_url(config, file)}) |")

    database = meta.get("sqlite") or {}
    if database:
        filename = database.get("file", "maldives.db")
        size = database.get("size") or f"{database.get('bytes', 0):,} bytes"
        lines += [
            "",
            f"Database: [`{filename}`]({public_url(config, filename)}) — {size}, "
            f"{database.get('tables', 0)} tables, {database.get('rows', 0):,} rows",
        ]

    if changed:
        lines += [
            "",
            f"Source layers changed in the last fetch: {', '.join(f'`{c}`' for c in changed)}.",
        ]
    else:
        lines += ["", "No source layers changed in the last fetch."]

    lines += ["", README_STATUS_END]
    return "\n".join(lines), changed, meta


def write_readme(readme_path, block):
    readme_path = Path(readme_path)
    text = readme_path.read_text(encoding="utf-8")
    start = text.find(README_STATUS_START)
    end = text.find(README_STATUS_END)
    if start == -1 or end == -1:
        raise RuntimeError(
            f"README is missing the {README_STATUS_START} / {README_STATUS_END} markers"
        )
    end += len(README_STATUS_END)
    updated = text[:start] + block + text[end:]
    if updated != text:
        readme_path.write_text(updated, encoding="utf-8")
    return updated != text
