# mv-locations

Scrape every layer of the Maldives Bureau of Statistics GIS map:

<https://app.statisticsmaldives.gov.mv/gismaps/statsmap/>

The map is a QGIS2Web export, so all data is published as static GeoJSON layer
files. There is no API key, login or pagination. `mv-locations` downloads those
files, joins them spatially, and publishes clean JSON/GeoJSON plus a single
SQLite database to a public OpenList share.

```
atolls (21) -> islands (1,187) -> roads (where published) -> addresses (92,465)
                                 \-> population, resorts, schools, reefs, ...
```

**The data is not stored in this repository.** Only the code and this README
(with the status block below) are committed. Local builds land in `data/`
(gitignored).

## Quick start

Python 3.9+ and **no third-party packages** are required.

```sh
python3 -m mv_locations update     # fetch all 26 layers + build JSON into ./data
python3 -m mv_locations status     # print the data status block
```

Other commands: `fetch` (download only), `build` (rebuild only), `--core`
(core layers only), `--compact` (smaller JSON).

## Read the data

Everything is published to a public OpenList share:

<https://index.cubable.date/@s/OLDOu9rQ> — access code `geo`

```
https://index.cubable.date/sd/OLDOu9rQ/<file>?pwd=geo
```

* `atolls.json`, `islands.json`, `roads.json`, `addresses.json`
* `maldives.json` (full atoll -> island -> roads + addresses hierarchy)
* `islands.geojson` (island polygons)
* `layers/<name>.geojson` (22 other layers) + `layers/index.json`
* `meta.json` (counts, data-quality stats, source freshness)
* `manifest.json` (fetch cache metadata)
* `maldives.db` (everything above in one SQLite database)

```sh
curl -sL "https://index.cubable.date/sd/OLDOu9rQ/islands.json?pwd=geo" | jq .
```

## Data status

The block below is rewritten by `python3 -m mv_locations status --write-readme`
and committed by the workflow, so the commit message tells you what changed.
The links are direct OpenList downloads (code `geo`).

<!-- DATA-STATUS:START -->

_Last run: `2026-10-24T03:23:53+00:00` · data generated: `2026-10-24T03:17:24+00:00`_

Download base: `https://index.cubable.date/sd/OLDOu9rQ/`

| Dataset | Records | Object |
| --- | ---: | --- |
| atolls | 21 | [`atolls.json`](https://index.cubable.date/sd/OLDOu9rQ/atolls.json?pwd=geo) |
| islands | 1,187 | [`islands.json`](https://index.cubable.date/sd/OLDOu9rQ/islands.json?pwd=geo) |
| roads | 743 | [`roads.json`](https://index.cubable.date/sd/OLDOu9rQ/roads.json?pwd=geo) |
| addresses | 92,465 | [`addresses.json`](https://index.cubable.date/sd/OLDOu9rQ/addresses.json?pwd=geo) |
| island_names | 1,187 | [`layers/island_names.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/island_names.geojson?pwd=geo) |
| atoll_boundaries | 22 | [`layers/atoll_boundaries.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/atoll_boundaries.geojson?pwd=geo) |
| atoll_capitals | 21 | [`layers/atoll_capitals.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/atoll_capitals.geojson?pwd=geo) |
| airports | 19 | [`layers/airports.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/airports.geojson?pwd=geo) |
| resorts | 174 | [`layers/resorts.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/resorts.geojson?pwd=geo) |
| schools | 269 | [`layers/schools.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/schools.geojson?pwd=geo) |
| hotels | 15 | [`layers/hotels.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/hotels.geojson?pwd=geo) |
| guest_houses | 83 | [`layers/guest_houses.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/guest_houses.geojson?pwd=geo) |
| mosques | 20 | [`layers/mosques.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/mosques.geojson?pwd=geo) |
| government_offices | 27 | [`layers/government_offices.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/government_offices.geojson?pwd=geo) |
| protected_areas | 93 | [`layers/protected_areas.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/protected_areas.geojson?pwd=geo) |
| reefs | 1,455 | [`layers/reefs.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/reefs.geojson?pwd=geo) |
| wetlands | 89 | [`layers/wetlands.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/wetlands.geojson?pwd=geo) |
| vegetation | 57 | [`layers/vegetation.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/vegetation.geojson?pwd=geo) |
| causeways | 9 | [`layers/causeways.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/causeways.geojson?pwd=geo) |
| runways | 19 | [`layers/runways.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/runways.geojson?pwd=geo) |
| wards | 12 | [`layers/wards.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/wards.geojson?pwd=geo) |
| parcels | 11,323 | [`layers/parcels.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/parcels.geojson?pwd=geo) |
| street_blocks | 21,452 | [`layers/street_blocks.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/street_blocks.geojson?pwd=geo) |
| plot_lines | 90,184 | [`layers/plot_lines.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/plot_lines.geojson?pwd=geo) |
| other_inhabited | 168 | [`layers/other_inhabited.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/other_inhabited.geojson?pwd=geo) |
| uninhabited | 1,373 | [`layers/uninhabited.geojson`](https://index.cubable.date/sd/OLDOu9rQ/layers/uninhabited.geojson?pwd=geo) |

Database: [`maldives.db`](https://index.cubable.date/sd/OLDOu9rQ/maldives.db?pwd=geo) — 70.7 MB, 26 tables, 222,487 rows

Source layers changed in the last fetch: `Address_24`, `AdministrativeAtoll_21`, `AdministrativeIsland_2`, `Airport_10`, `AtollBoundaryLine_20`, `AtollCapital_13`, `GovernmentOffice_18`, `GuestHouse_15`, `Hotels_14`, `IslandName_23`, `Mosque_17`, `OtherInhabited_12`, `ParcelCategory_5`, `ProtectedAreaEPA_25`, `Reef_0`, `Resort_16`, `Road_9`, `School_19`, `StreetBlock_4`, `Uninhabited_11`, `WardMaaleandFoahmulah_22`, `causeway_1`, `plotLine_8`, `runway_7`, `veg_3`, `wetland_6`.

<!-- DATA-STATUS:END -->

## Daily updates

The source files carry `ETag` and `Last-Modified` headers, so unchanged layers
are not downloaded twice. `update` fetches and rebuilds; the workflow then
publishes the result and refreshes the status block above.

Use `--core` on `fetch`/`update` to download only the 4 hierarchy layers and
skip the rest.

### Gitea Actions

`.gitea/workflows/update.yml` runs on a Gitea runner:

1. `update` — fetch + build;
2. publish the generated files (JSON, GeoJSON and the SQLite database) to the share;
3. `status --write-readme --summary` — refresh the README status block;
4. commit **only** `README.md` with
   `chore(data): refresh <timestamp> (...; changed: ...)`.

Data never enters git. Triggers: daily at 03:15 UTC, `workflow_dispatch`, and
pushes touching `mv_locations/`, `scripts/` or the workflow. `concurrency`
prevents overlapping runs, and the commit is skipped if the block is unchanged.

Requires a Gitea
[act_runner](https://docs.gitea.com/usage/actions/act-runner) with an
`ubuntu-latest` label and a token with write access to contents. Change the
branch in the `push:` trigger if your default branch is not `main`.

### Resilience to layer version changes

QGIS2Web renames layers when they are republished (`Address_24.js` becomes
`Address_25.js`, etc.). The scraper reads `index.html`, discovers the current
layer files, and matches them by prefix, so version bumps do not break it.

## Querying the data (no files on disk)

The public OpenList share is the read path. Everything stays in memory; nothing
is written to disk.

```sh
OL=https://index.cubable.date
SHARE=OLDOu9rQ
CODE=geo

geo() {
  curl -sL "$OL/sd/$SHARE/$1?pwd=$CODE"
}

# 10 most populated islands
geo islands.json \
  | jq -r '.islands | sort_by(-.population_total)[:10][] | "\(.population_total)\t\(.name)"'

# all addresses on one island
geo addresses.json \
  | jq '.addresses[] | select(.island == "Maafushi")'

# roads with the most addresses
geo roads.json \
  | jq -r '.roads | sort_by(-.address_count)[:10][] | "\(.address_count)\t\(.name)"'

# operating resorts
geo layers/resorts.geojson \
  | jq -r '.features[].properties | select(.state == "Operating") | .name'

# one island's full subtree (roads + addresses)
geo maldives.json \
  | jq '.atolls[] | select(.code == "K") | .islands[] | select(.name == "Maafushi")'
```

Browse or list the share without downloading. The JSON API needs the share
prefix in `path`:

```sh
curl -s -X POST "$OL/api/fs/list" \
  -H 'Content-Type: application/json' \
  -d "{\"path\":\"/@s/$SHARE\",\"password\":\"$CODE\",\"page\":1,\"per_page\":100}" \
  | jq -r '.data.content[] | "\(.size)\t\(.name)"'
```

Python needs no dependencies and no authentication:

```python
import json, urllib.request

url = "https://index.cubable.date/sd/OLDOu9rQ/maldives.json?pwd=geo"
data = json.load(urllib.request.urlopen(url))
atoll = next(a for a in data["atolls"] if a["code"] == "K")
island = next(i for i in atoll["islands"] if i["name"] == "Maafushi")
print(f"{island['name']}: {island['population_total']} people, {island['area_km2']} km2")
```

## SQLite database

`maldives.db` contains everything in one file: core tables (`atolls`,
`islands`, `roads`, `addresses`), one table per extra layer (e.g. `resorts`,
`schools`, `reefs`), plus `layers` and `meta` metadata tables.

```sh
curl -sL "https://index.cubable.date/sd/OLDOu9rQ/maldives.db?pwd=geo" -o maldives.db

sqlite3 maldives.db ".tables"
sqlite3 maldives.db "SELECT name, population_total FROM islands ORDER BY population_total DESC LIMIT 10;"
sqlite3 maldives.db "SELECT name, rooms FROM resorts WHERE state = 'Operating' ORDER BY rooms DESC LIMIT 5;"
sqlite3 maldives.db "SELECT atoll, count(*) FROM uninhabited GROUP BY atoll ORDER BY 2 DESC;"
```

* Geometry is stored as GeoJSON text in the `geometry` column; point features
  also have `longitude`/`latitude` columns.
* `islands` includes its polygon `geometry` and
  `min_lon`/`min_lat`/`max_lon`/`max_lat`.
* `layers` lists every extra table with its source file, feature count and
  fields. `meta` holds `generated_at`, counts, quality stats and more.

## Population & land area

The administrative island and atoll layers embed census figures. They are
surfaced on `islands.json`, `atolls.json`, `maldives.json` and
`islands.geojson`:

* `population_total`, `population_male`, `population_female`
* `population_maldivian`, `population_foreign`
* `area_km2` (computed from the polygon geometry)
* `population_density_per_km2`

Atolls additionally carry the source percentages (`population_pct`,
`population_foreign_pct`, `population_maldives_share_pct`,
`population_growth_pct`). National resident total reconciles to 448,164
(196,795 male / 251,369 female; 364,910 Maldivian / 83,254 foreign).

## Other layers

`layers/<name>.geojson` contains one normalized GeoJSON per source layer. Every
point / line / polygon that can be located is enriched with `island`,
`island_id`, `island_code`, `island_fcode`, `atoll` and `atoll_name`.

| Layer | Features | Geometry | Coverage | Notes |
| --- | --- | --- | --- | --- |
| `resorts` | 174 | point | nationwide | rooms, beds, owner, operator, contacts, state |
| `schools` | 269 | point | nationwide | name, status |
| `airports` | 19 | point | nationwide | IATA/ICAO codes, international flag, operator |
| `hotels` | 15 | point | nationwide | name, address |
| `guest_houses` | 83 | point | Greater Malé | name, address, rooms |
| `mosques` | 20 | point | Malé | name |
| `government_offices` | 27 | point | Malé | name, address, contact, email |
| `protected_areas` | 93 | polygon | nationwide | category, type, area, declaration/management dates, description, links |
| `reefs` | 1,455 | polygon | nationwide | name |
| `wetlands` | 89 | polygon | nationwide | name, area, length |
| `vegetation` | 57 | polygon | nationwide | ward, area |
| `causeways` | 9 | polygon | nationwide | area, length |
| `runways` | 19 | polygon | nationwide | area, length |
| `wards` | 12 | polygon | Malé + Fuvahmulah | English + Dhivehi names |
| `parcels` | 11,323 | polygon | Greater Malé | category, area |
| `street_blocks` | 21,452 | polygon | nationwide | block code |
| `plot_lines` | 90,184 | line | nationwide | block code |
| `other_inhabited` | 168 | point | nationwide | population |
| `uninhabited` | 1,373 | point | nationwide | category |
| `island_names` | 1,187 | point | nationwide | island point labels |
| `atoll_capitals` | 21 | point | nationwide | capital island + population |
| `atoll_boundaries` | 22 | line | nationwide | atoll outline |

## Data schema

### Address

```json
{
  "id": "A723E078ADF67",
  "name": "Royal Restaurent",
  "full_name": "Royal Restaurent, Fuvahmulah",
  "island": "Fuvahmulah",
  "island_id": "LD...",
  "island_code": "1730",
  "island_fcode": "LD...",
  "atoll": "Gn",
  "atoll_name": "Fuvammulah",
  "road": "Majeedhee Magu",
  "road_id": "R14D332999C6A",
  "road_unnamed": false,
  "road_distance_m": 4.3,
  "match": "polygon",
  "latitude": -0.3067098,
  "longitude": 73.4405584
}
```

* `match` is `polygon`, `name`, `fuzzy`, `nearest` or `unmatched`. It records how
  the point was assigned to an island: point-in-polygon first, then a
  normalized/fuzzy island-name fallback, then the nearest island boundary
  within 5 km for points just offshore.
* `source_island_name` is only present when the source label differs from the
  boundary island name (e.g. spelling variants, or a locality such as
  `Kalaidhoo`).
* `road` is `null` when no road within the matching radius exists, or when the
  nearest road has no name. `road_unnamed` distinguishes the latter.
* IDs are deterministic SHA-1-derived strings, so they stay stable between
  daily runs as long as the source record does.

### Road

Roads are grouped by `(island, road name)`; every unnamed road segment is kept
as its own record. Geometry is a GeoJSON `MultiLineString` in WGS84.

### Island

`id` is the source `FCODE`. A handful of `FCODE`s are reused by the source for
different islets; those get a coordinate-derived suffix (`LD1102-3F2A4B`).
`bbox` is `[minLon, minLat, maxLon, maxLat]`.

## Important data caveats

These come from the source map, not from the scraper:

* **Roads are only published for Malé.** The current export has 766 road
  segments / 743 road records, all inside Malé. Addresses on the other 1,186
  islands have `road: null`. If the Bureau expands coverage, a daily `update`
  will pick it up automatically.
* **"Addresses" are named places/buildings** (houses, shops, jetties, dive
  sites, benchmarks, ...) from the BBS Address layer, not postal addresses.
* **Some layers are partial.** Parcel *category* polygons, guest houses,
  mosques and government offices only cover Greater Malé / Malé. Everything
  else (roads, reefs, resorts, schools, protected areas, plot lines, street
  blocks) is nationwide.
* Uninhabited islands have no addresses. Some unnamed islands have `name: null`.
* A few source points are offshore; they are attached to the nearest island
  and flagged `match: "nearest"`, or left unmatched.
* The export is not guaranteed to change daily. `meta.json` -> `source_layers`
  records each layer's `Last-Modified` date so you can tell how fresh the
  snapshot is.

## Road matching

Addresses are attached to the nearest road segment within a radius:

* named roads: 30 m (`--road-radius`)
* unnamed roads: 15 m (`--unnamed-road-radius`)

A nearby named road wins over an unnamed lane, because Maldivian addresses use
road names. Tune the radii if needed:

```sh
python3 -m mv_locations build --road-radius 40 --unnamed-road-radius 20
```

## Attribution

Data source: Maldives Bureau of Statistics, `app.statisticsmaldives.gov.mv`.
Check the source site for terms of use and attribution requirements before
redistributing. This project only caches publicly served map files.
